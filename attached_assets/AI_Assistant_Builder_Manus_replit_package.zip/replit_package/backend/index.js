const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');
const winston = require('winston');
const jwt = require('jsonwebtoken');

// Load environment variables
dotenv.config();

// Initialize logger
const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.Console()
  ]
});

// Initialize Express app
const app = express();
const port = process.env.PORT || 5000;

// Middleware
app.use(cors({
  origin: process.env.CORS_ALLOWED_ORIGINS ? process.env.CORS_ALLOWED_ORIGINS.split(',') : '*'
}));
app.use(express.json());

// MongoDB connection (with retry logic)
const connectMongoDB = async () => {
  try {
    const mongoURI = process.env.MONGODB_URI || 'mongodb://localhost:27017/ai-automation';
    await mongoose.connect(mongoURI);
    logger.info('MongoDB connected successfully');
  } catch (error) {
    logger.error(`MongoDB connection error: ${error.message}`);
    logger.info('Retrying MongoDB connection in 5 seconds...');
    setTimeout(connectMongoDB, 5000);
  }
};

// Routes
app.get('/', (req, res) => {
  res.json({ message: 'Welcome to AI Automation Tool API' });
});

// Health check endpoint
app.get('/health', (req, res) => {
  const mongoStatus = mongoose.connection.readyState === 1 ? 'connected' : 'disconnected';
  
  res.json({
    status: 'ok',
    timestamp: new Date(),
    services: {
      mongodb: mongoStatus
    }
  });
});

// API routes
app.get('/api/workflows', (req, res) => {
  res.json([
    { id: 1, name: 'Gmail Lead Capture', active: true, triggers: ['new email'], actions: ['qualify lead', 'send response'] },
    { id: 2, name: 'Instagram Engagement', active: true, triggers: ['new message'], actions: ['analyze sentiment', 'send reply'] },
    { id: 3, name: 'Follow-up Sequence', active: false, triggers: ['scheduled'], actions: ['send email', 'update CRM'] }
  ]);
});

app.get('/api/templates', (req, res) => {
  res.json([
    { id: 1, name: 'Lead Response', content: 'Thank you for your interest in our services. A team member will contact you shortly.' },
    { id: 2, name: 'Product Inquiry', content: 'Thank you for your interest in {product}. Here are the details you requested: {details}' },
    { id: 3, name: 'Follow-up Email', content: 'Just checking in regarding our previous conversation about {topic}.' }
  ]);
});

app.get('/api/assistants', (req, res) => {
  res.json([
    { id: 1, name: 'Coordinator', role: 'Orchestrates the entire workflow' },
    { id: 2, name: 'Lead Qualifier', role: 'Evaluates and prioritizes incoming leads' },
    { id: 3, name: 'Content Writer', role: 'Generates personalized response content' },
    { id: 4, name: 'Data Analyst', role: 'Analyzes messages and extracts structured data' },
    { id: 5, name: 'Sales Specialist', role: 'Handles sales strategies and follow-ups' },
    { id: 6, name: 'Support Specialist', role: 'Manages support inquiries and troubleshooting' }
  ]);
});

// Start server
if (require.main === module) {
  app.listen(port, () => {
    logger.info(`Server running on port ${port}`);
    connectMongoDB();
  });
}

module.exports = app;

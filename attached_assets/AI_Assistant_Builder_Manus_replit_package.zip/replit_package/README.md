# AI Automation Tool - Replit Deployment Guide

This guide provides instructions for deploying the AI Automation Tool on Replit, a cloud-based development environment.

## Project Structure

The AI Automation Tool consists of two main components:

1. **Backend**: Node.js Express server that handles API requests, connects to databases, and manages AI assistants
2. **Frontend**: React application that provides the user interface for workflow building and management

For Replit deployment, we'll use a simplified structure that combines both components in a single Replit project.

## Deployment Steps

### 1. Create a New Replit Project

1. Go to [Replit](https://replit.com/) and sign in or create an account
2. Click "Create Repl"
3. Select "Node.js" as the template
4. Name your project (e.g., "ai-automation-tool")
5. Click "Create Repl"

### 2. Set Up Project Structure

Create the following directory structure in your Replit project:

```
/
├── backend/
│   ├── index.js
│   ├── package.json
│   └── ... (other backend files)
├── frontend/
│   ├── build/
│   │   ├── index.html
│   │   ├── static/
│   │   └── ... (other frontend build files)
│   └── ... (frontend source files)
├── .env
├── .replit
├── replit.nix
└── index.js (main entry point)
```

### 3. Configure Backend

1. Upload the backend files to the `backend/` directory
2. Install required dependencies:
   ```bash
   cd backend
   npm install express mongoose redis jsonwebtoken cors dotenv winston
   ```

### 4. Configure Frontend

For Replit deployment, we'll use a pre-built version of the frontend:

1. Build the frontend locally:
   ```bash
   cd frontend
   npm install
   npm run build
   ```
2. Upload the contents of the `build/` directory to the `frontend/build/` directory in Replit

### 5. Create Main Entry Point

Create a `index.js` file in the root directory with the following content:

```javascript
const express = require('express');
const path = require('path');
const backend = require('./backend/index');

const app = express();
const PORT = process.env.PORT || 3000;

// Serve static files from the React app
app.use(express.static(path.join(__dirname, 'frontend/build')));

// Use the backend API routes
app.use('/api', backend);

// For any request that doesn't match the above, serve the React app
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'frontend/build', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
```

### 6. Configure Environment Variables

Create a `.env` file in the root directory with the following content:

```
NODE_ENV=production
PORT=3000
LOG_LEVEL=info
MONGODB_URI=mongodb+srv://<username>:<password>@<cluster>.mongodb.net/ai-automation
JWT_SECRET=your_secure_jwt_secret
GMAIL_API_KEY=your_gmail_api_key
GMAIL_API_SECRET=your_gmail_api_secret
INSTAGRAM_API_KEY=your_instagram_api_key
INSTAGRAM_API_SECRET=your_instagram_api_secret
```

Replace the placeholder values with your actual credentials.

### 7. Configure Replit

Create a `.replit` file in the root directory with the following content:

```
language = "nodejs"
run = "npm start"
```

Create a `package.json` file in the root directory with the following content:

```json
{
  "name": "ai-automation-tool",
  "version": "1.0.0",
  "description": "AI Automation Tool for connecting AI assistants to apps and automating business tasks",
  "main": "index.js",
  "scripts": {
    "start": "node index.js",
    "dev": "nodemon index.js"
  },
  "dependencies": {
    "express": "^4.18.2",
    "path": "^0.12.7"
  },
  "devDependencies": {
    "nodemon": "^2.0.22"
  }
}
```

### 8. Run the Application

1. In the Replit shell, run:
   ```bash
   npm install
   ```
2. Click the "Run" button or type:
   ```bash
   npm start
   ```
3. Your application should now be running and accessible via the Replit URL

## Database Setup

For Replit deployment, we recommend using MongoDB Atlas for the database:

1. Create a free MongoDB Atlas account at [https://www.mongodb.com/cloud/atlas](https://www.mongodb.com/cloud/atlas)
2. Create a new cluster
3. Set up a database user and password
4. Get your connection string and update the `MONGODB_URI` in your `.env` file

## Troubleshooting

### Application Not Starting
- Check the Replit console for error messages
- Verify that all dependencies are installed
- Ensure environment variables are correctly set

### Database Connection Issues
- Verify your MongoDB Atlas connection string
- Ensure your IP address is whitelisted in MongoDB Atlas
- Check that your database user has the correct permissions

### Frontend Not Loading
- Verify that the frontend build files are correctly placed in the `frontend/build/` directory
- Check that the main `index.js` file is correctly serving the static files

## Next Steps

After deploying your AI Automation Tool on Replit, you can:

1. Connect it to your Gmail and Instagram accounts
2. Create workflows using the visual builder
3. Set up templates for automated responses
4. Configure your team of AI assistants
5. Monitor performance through the analytics dashboard

For any issues or questions, refer to the comprehensive documentation or contact support.
